import java.io.*;
import java.util.*;

public class MacroP1 {

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader("macro_input.txt"));
		
		FileWriter MNT = new FileWriter("MNT.txt");			// Macro Name Table
		FileWriter MDT = new FileWriter("MDT.txt");			// Macro Definition Table
		FileWriter KPDT = new FileWriter("KPDT.txt");		// Keyword Parameter Default values Table
		FileWriter PNT = new FileWriter("PNT.txt");			// Parameter Name Table
		FileWriter IC = new FileWriter("IC_output.txt");	// Intermediate Code
		
		LinkedHashMap<String, Integer> pntab = new LinkedHashMap<>();
		String line;
		String macroName = null;
		boolean macro = false;
		int mdtp = 1, kpdtp = 0;
		
		while ((line = reader.readLine()) != null) {
			String[] parts = line.split("\\s+");
			
			// Macro start
			if (parts[0].equalsIgnoreCase("MACRO")) {
				macro = true;
				line = reader.readLine();
				parts = line.split("\\s+");
				macroName = parts[0];
				
				// No parameters
				if (parts.length == 1) {
					MNT.write(String.format("%s\t0\t0\t%d\t%d\n", parts[0], mdtp, kpdtp));
					continue;
				}
				
				// Processing parameters
				int pp = 0, kp = 0, paramNo = 1;
				for (int i = 1; i < parts.length; i++) {
					parts[i] = parts[i].replaceAll("[&,]", "");
					// Keyword parameter
					if (parts[i].contains("=")) {
						kp++;
						String[] param = parts[i].split("=");
						pntab.put(param[0], paramNo++);
						KPDT.write(String.format("%s\t%s\n", param[0], param[1]));
					}
					// Positional parameter
					else {
						pp++;
						pntab.put(parts[i], paramNo++);
					}
				}
				
				MNT.write(String.format("%s\t%d\t%d\t%d\t%d\n", parts[0], pp, kp, mdtp, (kp==0 ? kpdtp : kpdtp+1)));
				kpdtp += kp;
			}
			
			// Macro end
			else if (parts[0].equalsIgnoreCase("MEND")) {
				MDT.write(line + "\n");
				macro = false;
				mdtp++;
				String toWrite = macroName + ":\t";
				for (String param : pntab.keySet()) {
					toWrite += param + "\t";
				}
				PNT.write(toWrite + "\n");
				pntab.clear();
			}
			
			// Macro statements
			else if (macro) {
				String toWrite = "";
				for (int i = 0; i < parts.length; i++) {
					if (parts[i].contains("&")) {
						parts[i] = parts[i].replaceAll("[&,]", "");
						toWrite += "#" + pntab.get(parts[i]) + "\t";
					} else {
						toWrite += parts[i] + "\t";
					}
				}
				MDT.write(toWrite + "\n");
				mdtp++;
			}
			
			// Normal statements
			else {
				IC.write(line + "\n");
			}
		}
		
		reader.close();
		MDT.close();
		MNT.close();
		IC.close();
		KPDT.close();
		PNT.close();
	}

}
