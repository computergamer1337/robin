import java.io.*;
import java.util.*;

public class Pass1 {

	public static int address = 0;
	public static int poolPtr = 0;
	public static int symIndex = 0, litIndex = 0;
	public static LinkedHashMap<String, Row> SYMTAB;
	public static ArrayList<Row> LITTAB;
	public static ArrayList<Integer> POOLTAB;
	private static BufferedReader reader;
	
	public static void main(String[] args) throws IOException {
		SYMTAB = new LinkedHashMap<>();
		LITTAB = new ArrayList<>();
		POOLTAB = new ArrayList<>();
		POOLTAB.add(0);
		
		String line;
		reader = new BufferedReader(new FileReader("input.txt"));
		BufferedWriter writer = new BufferedWriter(new FileWriter("IC.txt"));
		MOT mot = new MOT();
		
		while ((line = reader.readLine()) != null) {
			line = line.replace(',', ' ').toUpperCase();
			String[] parts = line.trim().split("\\s+");
			int i = 0;
			String code = "";
			
			// Label
			if (mot.getCode(parts[0]) == -1) {
				if (SYMTAB.containsKey(parts[0])) {
					SYMTAB.put(parts[0], new Row(parts[0], address, SYMTAB.get(parts[0]).getIndex()));
				} else {
					SYMTAB.put(parts[0], new Row(parts[0], address, symIndex++));
				}
				i++;
			}
			
			// START
			if (parts[0].equals("START")) {
				address = Integer.parseInt(parts[1]);
				code = "\t(AD, 01)\t(C, " + address + ")\n";
				writer.write(code);
				continue;
			}
			
			// ORIGIN 
			if (parts[0].equals("ORIGIN")) {
				address = evaluate(parts[1]);
				code = "\t(AD, 03)\t(C, " + address + ")\n";
				writer.write(code);
				continue;
			}
			
			// EQU
			if (parts.length > 2 && parts[1].equals("EQU")) {
				int val = evaluate(parts[2]);
				if (SYMTAB.containsKey(parts[0])) {
					SYMTAB.put(parts[0], new Row(parts[0], val, SYMTAB.get(parts[0]).getIndex()));
				} else {
					SYMTAB.put(parts[0], new Row(parts[0], val, symIndex++));
				}
				code = String.format("\t(AD, 04)\t(C, %d)\n", val);
				writer.write(code);
				continue;
			}
			
			// LTORG
			if (parts[0].equals("LTORG")) {
				int ptr = POOLTAB.get(poolPtr);
				for (int j = ptr; j < litIndex; j++) {
					LITTAB.set(j, new Row(LITTAB.get(j).getSymbol(), address));
					code = String.format("%d\t(DL, 02)\t(C, %s)\n", address, LITTAB.get(j).getSymbol());
					writer.write(code);
					address++;
				}
				poolPtr++;
				POOLTAB.add(litIndex);
				continue;
			}
			
			// END
			if (parts[0].equals("END")) {
				writer.write("\t(AD, 02)\n");
				int ptr = POOLTAB.get(poolPtr);
				for (int j = ptr; j < litIndex; j++) {
					LITTAB.set(j, new Row(LITTAB.get(j).getSymbol(), address));
					code = String.format("%d\t(DL, 02)\t(C, %s)\n", address, LITTAB.get(j).getSymbol());
					writer.write(code);
					address++;
				}
				poolPtr++;
				POOLTAB.add(litIndex);
				continue;
			}
			
			// DC
			if (parts.length > 2 && parts[1].equals("DC")) {
				int val = Integer.parseInt(parts[2].replace("'", ""));
				if (SYMTAB.containsKey(parts[0])) {
					SYMTAB.put(parts[0], new Row(parts[0], address, SYMTAB.get(parts[0]).getIndex()));
				} else {
					SYMTAB.put(parts[0], new Row(parts[0], address, symIndex++));
				}
				code = String.format("%d\t(DL, 02)\t(C, %d)\n", address, val);
				writer.write(code);
				address++;
				continue;
			}
			
			// DS
			if (parts.length > 2 && parts[1].equals("DS")) {
				int val = Integer.parseInt(parts[2].replace("'", ""));
				if (SYMTAB.containsKey(parts[0])) {
					SYMTAB.put(parts[0], new Row(parts[0], address, SYMTAB.get(parts[0]).getIndex()));
				} else {
					SYMTAB.put(parts[0], new Row(parts[0], address, symIndex++));
				}
				code = String.format("%d\t(DL, 01)\t(C, %d)\n", address, val);
				writer.write(code);
				address += val;
				continue;
			}
			
			// All other IS
			if (mot.getType(parts[i]).equals("IS")) {
				code = String.format("%d\t(IS, %02d)\t", address, mot.getCode(parts[i]));
				i++;
				
				while (i < parts.length) {
					if (mot.getCode(parts[i]) != -1) {
						code += String.format("(%s, %02d)\t", mot.getType(parts[i]), mot.getCode(parts[i]));
					} else {
						if (parts[i].contains("=")) {
							parts[i] = parts[i].replace("=", "").replace("'", "");
							code += String.format("(L, %02d)\t", litIndex);
							LITTAB.add(new Row(parts[i], -1, litIndex++));
						} 
						else if (SYMTAB.containsKey(parts[i])) {
							code += String.format("(S, %02d)\t", SYMTAB.get(parts[i]).getIndex());
						} else {
							code += String.format("(S, %02d)\t", symIndex);
							SYMTAB.put(parts[i], new Row(parts[i], -1, symIndex++));
						}
					}
					i++;
				}
				
				writer.write(code + "\n");
				address++;
			}
		}
		
		reader.close();
		writer.close();
		printSYMTAB();
		printLITTAB();
		printPOOLTAB();
	}
	
	public static int evaluate(String s) {
		if (s.contains("+")) {
			String[] splits = s.split("\\+");
			return SYMTAB.get(splits[0]).getAddress() + Integer.parseInt(splits[1]);
		}
		if (s.contains("-")) {
			String[] splits = s.split("\\-");
			return SYMTAB.get(splits[0]).getAddress() - Integer.parseInt(splits[1]);
		}
		return Integer.parseInt(s);
	}
	
	public static void printSYMTAB() throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter("SYMTAB.txt"));
		System.out.println("\nSymbol Table:");
		for (Map.Entry<String, Row> entry : SYMTAB.entrySet()) {
			String key = entry.getKey();
			Row value = entry.getValue();
			String s = String.format("%d\t%s\t%d\n", value.getIndex(), key, value.getAddress());
			System.out.print(s);
			writer.write(s);
		}
		writer.close();
	}
	
	public static void printLITTAB() throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter("LITTAB.txt"));
		System.out.println("\nLiteral Table:");
		for (int i = 0; i < LITTAB.size(); i++) {
			Row row = LITTAB.get(i);
			String s = String.format("%d\t%s\t%d\n", i, row.getSymbol(), row.getAddress());
			System.out.print(s);
			writer.write(s);
		}
		writer.close();
	}
	
	public static void printPOOLTAB() throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter("POOLTAB.txt"));
		System.out.println("\nPool Table:");
		for (int i = 0; i < POOLTAB.size(); i++) {
			String s = i + "\t" + POOLTAB.get(i) + "\n";
			System.out.print(s);
			writer.write(s);
		}
		writer.close();
	}

}
