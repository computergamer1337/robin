import java.util.Scanner;

public class RoundRobin {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter number of processes: ");
		int n = in.nextInt();
		int[] bt = new int[n];
		int[] wt = new int[n];
		int[] tat = new int[n];
		int[] rem = new int[n];
		
		for (int i = 0; i < n; i++) {
			System.out.print("Enter burst time for process " + (i+1) + ": ");
			bt[i] = rem[i] = in.nextInt();
		}
		
		System.out.print("Enter quantum value: ");
		int q = in.nextInt();
		
		in.close();
		
		boolean flag = true;
		int currTime = 0;
		while (flag) {
			flag = false;
			for (int i = 0; i < n; i++) {
				if (rem[i] > q) {
					currTime += q;
					rem[i] -= q;
					flag = true;
				}
				else if (rem[i] > 0) {
					currTime += rem[i];
					rem[i] = 0;
					tat[i] = currTime;
				}
			}
		}
		
		float total_wt = 0;
		float total_tat = 0;
		System.out.println("\nPID\tBT\tTAT\tWT");
		for (int i = 0; i < n; i++) {
			wt[i] = tat[i] - bt[i];
			total_wt += wt[i];
			total_tat += tat[i];
			System.out.println(String.format("%d\t%d\t%d\t%d", i+1, bt[i], tat[i], wt[i]));
		}
		
		System.out.println("\nAverage waiting time: " + (total_wt / n));
		System.out.println("Average turn around time: " + (total_tat / n));
	}

}
