public class Row {

	public String symbol;
	public int address, index;
	
	public Row(String symbol, int address, int index) {
		this.symbol = symbol;
		this.address = address;
		this.index = index;
	}

}
